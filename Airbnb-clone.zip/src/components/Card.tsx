import React from "react";
// import cardperson from "../assets/katie-zaferes.png";
import star from "../assets/star.png";



// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Spread_syntax#spread_in_object_literals

interface Props {
  image: string;
  rating: number;
  rC: number;
  location: string;
  title: string;
  price: number;
  openSpots: number;

}

const Card = ({ image, rating, rC, location, title, price, openSpots }: Props) => {
  let badgeText
  if (openSpots === 0) {
      badgeText = "SOLD OUT"
  } else if (location === "Online") {
      badgeText = "ONLINE"
  }
  return (
    <div className="card">
      {/* { !openSpots && <div className="card--badge">{badgeText}</div>} */}
      { badgeText && <div className="card--badge">{badgeText}</div>}
      <img src={`../public/${image}`} className="card--image" />
      <div className="card--stats">
        <img src={star} className="card--star" />
        <span>{rating}</span>
        <span className="gray">({rC}) • </span>
        <span className="gray">{location}</span>
      </div>
      <p>{title}</p>
      <p>
        <span className="bold">From ${price}</span> / person
      </p>
    </div>
  );
};

export default Card;
